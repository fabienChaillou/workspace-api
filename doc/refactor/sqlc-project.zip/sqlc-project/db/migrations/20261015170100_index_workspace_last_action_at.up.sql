-- CREATE INDEX CONCURRENTLY ne peut pas tourner dans une transaction :
-- garde ce fichier séparé (et désactive la transaction si ton outil
-- de migration l'impose, ex. "-- +goose NO TRANSACTION" avec goose).
-- Index partiels : seules les lignes vivantes sont interrogées.

-- Tri + pagination de ListWorkspaces.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_workspaces_last_action_at
    ON workspaces (last_action_at DESC NULLS LAST, id)
    WHERE deleted_at IS NULL;

-- Filtre EXISTS sur le type d'action.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_actions_workspace_type
    ON actions (workspace_id, type)
    WHERE deleted_at IS NULL;

-- Recalcul du max(updated_at) dans le trigger.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_actions_workspace_updated_at
    ON actions (workspace_id, updated_at DESC)
    WHERE deleted_at IS NULL;
