-- Version adaptée au soft delete : seules les actions vivantes
-- (deleted_at IS NULL) comptent pour last_action_at.

-- 1. Colonne nullable sans valeur par défaut : instantané, même sur une grosse table.
ALTER TABLE workspaces ADD COLUMN last_action_at timestamptz;

-- 2. Recalcul complet pour un workspace (utilisé quand le max a pu disparaître).
CREATE OR REPLACE FUNCTION refresh_workspace_last_action_at(p_workspace_id uuid)
RETURNS void
LANGUAGE sql
AS $$
    UPDATE workspaces
    SET last_action_at = (
        SELECT max(a.updated_at)
        FROM actions a
        WHERE a.workspace_id = p_workspace_id
          AND a.deleted_at IS NULL
    )
    WHERE id = p_workspace_id;
$$;

-- 3. Trigger qui maintient workspaces.last_action_at à jour.
--    Créé AVANT le backfill pour ne rater aucune écriture concurrente.
CREATE OR REPLACE FUNCTION sync_workspace_last_action_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    -- Suppression physique : le max a peut-être disparu.
    IF TG_OP = 'DELETE' THEN
        PERFORM refresh_workspace_last_action_at(OLD.workspace_id);
        RETURN NULL;
    END IF;

    -- Soft delete, restauration ou changement de workspace : recalcul.
    IF TG_OP = 'UPDATE'
       AND (OLD.workspace_id <> NEW.workspace_id
            OR OLD.deleted_at IS DISTINCT FROM NEW.deleted_at) THEN
        PERFORM refresh_workspace_last_action_at(OLD.workspace_id);
        IF NEW.workspace_id <> OLD.workspace_id THEN
            PERFORM refresh_workspace_last_action_at(NEW.workspace_id);
        END IF;
        RETURN NULL;
    END IF;

    -- Insert ou update d'une action vivante : on avance la date seulement
    -- si elle est plus récente (évite les écritures inutiles sur workspaces).
    IF NEW.deleted_at IS NULL THEN
        UPDATE workspaces
        SET last_action_at = NEW.updated_at
        WHERE id = NEW.workspace_id
          AND (last_action_at IS NULL OR last_action_at < NEW.updated_at);
    END IF;

    RETURN NULL; -- trigger AFTER : valeur de retour ignorée
END;
$$;

CREATE TRIGGER actions_sync_last_action_at
AFTER INSERT OR UPDATE OF updated_at, workspace_id, deleted_at OR DELETE ON actions
FOR EACH ROW EXECUTE FUNCTION sync_workspace_last_action_at();

-- 4. Backfill des workspaces existants (actions vivantes uniquement).
--    La condition "<" ne fait pas régresser une valeur déjà écrite par le trigger.
UPDATE workspaces w
SET last_action_at = la.max_updated_at
FROM (
    SELECT workspace_id, max(updated_at) AS max_updated_at
    FROM actions
    WHERE deleted_at IS NULL
    GROUP BY workspace_id
) la
WHERE la.workspace_id = w.id
  AND (w.last_action_at IS NULL OR w.last_action_at < la.max_updated_at);
