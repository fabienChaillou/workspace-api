-- name: ListWorkspaces :many
-- Page de workspaces triés par dernière action (sans action = en fin de liste).
-- Paramètres nullables : NULL = pas de filtre. "name" doit déjà être échappé
-- côté Go (%, _ et \) pour une recherche partielle littérale.
SELECT sqlc.embed(w), count(*) OVER() AS total
FROM workspaces w
WHERE w.deleted_at IS NULL
  AND (sqlc.narg('name')::text IS NULL OR w.name ILIKE '%' || sqlc.narg('name')::text || '%')
  AND (sqlc.narg('namespace')::text IS NULL OR w.namespace = sqlc.narg('namespace')::text)
  AND (sqlc.narg('action_type')::text IS NULL OR EXISTS (
        SELECT 1 FROM actions a
        WHERE a.workspace_id = w.id
          AND a.type = sqlc.narg('action_type')::text
          AND a.deleted_at IS NULL
      ))
ORDER BY w.last_action_at DESC NULLS LAST, w.id
LIMIT sqlc.arg('limit')::int OFFSET sqlc.arg('offset')::int;

-- name: CountWorkspaces :one
-- Même filtres que ListWorkspaces, pour une page au-delà de la fin.
SELECT count(*)
FROM workspaces w
WHERE w.deleted_at IS NULL
  AND (sqlc.narg('name')::text IS NULL OR w.name ILIKE '%' || sqlc.narg('name')::text || '%')
  AND (sqlc.narg('namespace')::text IS NULL OR w.namespace = sqlc.narg('namespace')::text)
  AND (sqlc.narg('action_type')::text IS NULL OR EXISTS (
        SELECT 1 FROM actions a
        WHERE a.workspace_id = w.id
          AND a.type = sqlc.narg('action_type')::text
          AND a.deleted_at IS NULL
      ));

-- name: GetWorkspace :one
SELECT * FROM workspaces
WHERE id = @id AND deleted_at IS NULL;

-- name: CreateWorkspace :one
INSERT INTO workspaces (
    name, vcs_url, vcs_key_str, vcs_branch, vcs_directory,
    status, env_vars, namespace, tofu_version
) VALUES (
    @name, @vcs_url, @vcs_key_str, @vcs_branch, @vcs_directory,
    @status, @env_vars, @namespace, @tofu_version
)
RETURNING *;

-- name: UpdateWorkspace :one
UPDATE workspaces
SET name          = @name,
    vcs_url       = @vcs_url,
    vcs_key_str   = @vcs_key_str,
    vcs_branch    = @vcs_branch,
    vcs_directory = @vcs_directory,
    env_vars      = @env_vars,
    tofu_version  = @tofu_version,
    updated_at    = now()
WHERE id = @id AND deleted_at IS NULL
RETURNING *;

-- name: UpdateWorkspaceStatus :one
UPDATE workspaces
SET status = @status, updated_at = now()
WHERE id = @id AND deleted_at IS NULL
RETURNING *;

-- name: SoftDeleteWorkspace :execrows
UPDATE workspaces
SET deleted_at = now(), updated_at = now()
WHERE id = @id AND deleted_at IS NULL;
