-- name: ListActionsByWorkspace :many
SELECT * FROM actions
WHERE workspace_id = @workspace_id AND deleted_at IS NULL
ORDER BY updated_at DESC, id;

-- name: GetAction :one
SELECT * FROM actions
WHERE id = @id AND deleted_at IS NULL;

-- name: CreateAction :one
-- Le trigger met à jour workspaces.last_action_at.
INSERT INTO actions (workspace_id, type, status)
VALUES (@workspace_id, @type, @status)
RETURNING *;

-- name: UpdateActionStatus :one
-- updated_at = now() déclenche la mise à jour de workspaces.last_action_at.
UPDATE actions
SET status = @status, updated_at = now()
WHERE id = @id AND deleted_at IS NULL
RETURNING *;

-- name: SoftDeleteAction :execrows
UPDATE actions
SET deleted_at = now(), updated_at = now()
WHERE id = @id AND deleted_at IS NULL;

-- name: SoftDeleteActionsByWorkspace :execrows
UPDATE actions
SET deleted_at = now(), updated_at = now()
WHERE workspace_id = @workspace_id AND deleted_at IS NULL;
