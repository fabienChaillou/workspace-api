-- name: ListVariablesByWorkspace :many
SELECT * FROM variables
WHERE workspace_id = @workspace_id AND deleted_at IS NULL
ORDER BY name;

-- name: UpsertVariable :one
-- Crée la variable, ou met à jour la variable vivante du même nom.
INSERT INTO variables (workspace_id, name, value, secure, hidden)
VALUES (@workspace_id, @name, @value, @secure, @hidden)
ON CONFLICT (workspace_id, name) WHERE deleted_at IS NULL
DO UPDATE SET
    value      = EXCLUDED.value,
    secure     = EXCLUDED.secure,
    hidden     = EXCLUDED.hidden,
    updated_at = now()
RETURNING *;

-- name: SoftDeleteVariable :execrows
UPDATE variables
SET deleted_at = now(), updated_at = now()
WHERE workspace_id = @workspace_id AND name = @name AND deleted_at IS NULL;

-- name: SoftDeleteVariablesByWorkspace :execrows
UPDATE variables
SET deleted_at = now(), updated_at = now()
WHERE workspace_id = @workspace_id AND deleted_at IS NULL;
