-- name: ListNamespaces :many
SELECT * FROM namespaces
WHERE deleted_at IS NULL
ORDER BY name;

-- name: GetNamespaceByName :one
SELECT * FROM namespaces
WHERE name = @name AND deleted_at IS NULL;

-- name: CreateNamespace :one
INSERT INTO namespaces (name, status)
VALUES (@name, @status)
RETURNING *;

-- name: UpdateNamespaceStatus :one
UPDATE namespaces
SET status = @status, updated_at = now()
WHERE id = @id AND deleted_at IS NULL
RETURNING *;

-- name: SoftDeleteNamespace :execrows
UPDATE namespaces
SET deleted_at = now(), updated_at = now()
WHERE id = @id AND deleted_at IS NULL;
