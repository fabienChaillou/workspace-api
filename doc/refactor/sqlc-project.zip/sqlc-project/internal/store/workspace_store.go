package store

import (
	"context"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/example/terraform-module/internal/db"
)

// WorkspaceStore enveloppe le code généré par sqlc : normalisation de la
// pagination, échappement de la recherche, total quand la page est vide.
type WorkspaceStore struct {
	q *db.Queries
}

func NewWorkspaceStore(pool *pgxpool.Pool) *WorkspaceStore {
	return &WorkspaceStore{q: db.New(pool)}
}

// ListWorkspacesFilter : un champ nil ou vide = pas de filtre.
type ListWorkspacesFilter struct {
	Name       *string // recherche partielle, insensible à la casse
	ActionType *string // workspaces ayant au moins une action vivante de ce type
	Namespace  *string // égalité stricte
	Page       int     // commence à 1
	Limit      int
}

type Pagination struct {
	TotalWorkspaces int `json:"totalWorkspaces"`
	Page            int `json:"page"`
	Limit           int `json:"limit"`
}

const (
	defaultLimit = 20
	maxLimit     = 100
)

func (s *WorkspaceStore) ListWorkspaces(ctx context.Context, f ListWorkspacesFilter) ([]db.Workspace, Pagination, error) {
	page, limit := normalizePage(f.Page, f.Limit)
	name := escapedLike(f.Name)
	namespace := nilIfEmpty(f.Namespace)
	actionType := nilIfEmpty(f.ActionType)

	rows, err := s.q.ListWorkspaces(ctx, db.ListWorkspacesParams{
		Name:       name,
		Namespace:  namespace,
		ActionType: actionType,
		Limit:      int32(limit),
		Offset:     int32((page - 1) * limit),
	})
	if err != nil {
		return nil, Pagination{}, fmt.Errorf("list workspaces: %w", err)
	}

	workspaces := make([]db.Workspace, 0, len(rows))
	var total int64
	for _, r := range rows {
		workspaces = append(workspaces, r.Workspace)
		total = r.Total
	}

	// Page au-delà de la fin : la window function ne renvoie aucune ligne.
	if len(rows) == 0 && page > 1 {
		total, err = s.q.CountWorkspaces(ctx, db.CountWorkspacesParams{
			Name:       name,
			Namespace:  namespace,
			ActionType: actionType,
		})
		if err != nil {
			return nil, Pagination{}, fmt.Errorf("count workspaces: %w", err)
		}
	}

	return workspaces, Pagination{TotalWorkspaces: int(total), Page: page, Limit: limit}, nil
}

func normalizePage(page, limit int) (int, int) {
	if page < 1 {
		page = 1
	}
	if limit <= 0 {
		limit = defaultLimit
	}
	if limit > maxLimit {
		limit = maxLimit
	}
	return page, limit
}

func nilIfEmpty(s *string) *string {
	if s == nil || *s == "" {
		return nil
	}
	return s
}

// escapedLike échappe %, _ et \ pour une recherche ILIKE littérale.
var likeEscaper = strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`)

func escapedLike(s *string) *string {
	if s == nil || *s == "" {
		return nil
	}
	escaped := likeEscaper.Replace(*s)
	return &escaped
}
