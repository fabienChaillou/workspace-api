package store

import (
	"fmt"
	"strings"

	"github.com/example/workspace-api/internal/domain"
)

// LastActionJoin joins, for each workspace aliased "w", its last live action
// as "la": the one with the latest updated_at, ties broken by the smallest id
// (same order as ListActions). Every la.* column is NULL when the workspace
// has no action. Backed by the partial index idx_actions_workspace_updated.
const LastActionJoin = `LEFT JOIN LATERAL (
	SELECT a.id, a.type, a.status, a.created_at, a.updated_at
	FROM actions a
	WHERE a.workspace_id = w.id AND a.deleted_at IS NULL
	ORDER BY a.updated_at DESC, a.id
	LIMIT 1
) la ON true`

// LastActionColumns selects the joined last action with unambiguous aliases.
const LastActionColumns = `la.id AS la_id, la.type AS la_type, la.status AS la_status,
	la.created_at AS la_created_at, la.updated_at AS la_updated_at`

var sortColumns = map[domain.SortField]string{
	domain.SortByActionsUpdatedAt: "la.updated_at",
	domain.SortByUpdatedAt:        "w.updated_at",
	domain.SortByCreatedAt:        "w.created_at",
	domain.SortByName:             "w.name",
}

// WorkspaceOrderBy returns the ORDER BY clause (without the keywords) for
// normalized options. Columns come from a whitelist, never from user input.
// NULLS LAST keeps workspaces without actions at the end in both directions;
// w.updated_at and w.id make the order total so pagination is stable.
func WorkspaceOrderBy(o domain.ListWorkspacesOptions) string {
	col, ok := sortColumns[o.Sort]
	if !ok {
		col = sortColumns[domain.SortByActionsUpdatedAt]
	}
	dir := "DESC"
	if o.Order == domain.SortAsc {
		dir = "ASC"
	}
	return fmt.Sprintf("%s %s NULLS LAST, w.updated_at DESC, w.id ASC", col, dir)
}

// WorkspaceWhere returns the WHERE condition (without the keyword) for the
// list filters, using "?" placeholders, and its arguments.
func WorkspaceWhere(f domain.QueryParams) (string, []any) {
	conds := []string{"w.deleted_at IS NULL"}
	var args []any
	if f.Name != "" {
		conds = append(conds, `w.name ILIKE ? ESCAPE '\'`)
		args = append(args, "%"+EscapeLike(f.Name)+"%")
	}
	if f.Status != "" {
		conds = append(conds, "w.status = ?")
		args = append(args, string(f.Status))
	}
	if f.Namespace != "" {
		conds = append(conds, "w.namespace = ?")
		args = append(args, f.Namespace)
	}
	if f.ActionType != "" {
		conds = append(conds, `EXISTS (
	SELECT 1 FROM actions fa
	WHERE fa.workspace_id = w.id AND fa.deleted_at IS NULL AND fa.type = ?
)`)
		args = append(args, string(f.ActionType))
	}
	return strings.Join(conds, " AND "), args
}

// EscapeLike escapes the LIKE wildcards so user input is matched literally.
func EscapeLike(s string) string {
	return strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`).Replace(s)
}

// Dollarize rewrites "?" placeholders into PostgreSQL "$n" placeholders,
// starting at $start. The queries built here never contain a literal "?".
func Dollarize(sql string, start int) string {
	var b strings.Builder
	n := start
	for _, r := range sql {
		if r == '?' {
			fmt.Fprintf(&b, "$%d", n)
			n++
			continue
		}
		b.WriteRune(r)
	}
	return b.String()
}
