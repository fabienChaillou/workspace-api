package store

import (
	"errors"
	"fmt"
	"strings"

	"github.com/example/workspace-api/internal/domain"
	"github.com/jackc/pgx/v5/pgconn"
)

// MapPgError translates PostgreSQL constraint errors into domain errors. Both
// stores use it (gorm runs on pgx too), so they report conflicts identically,
// including the offending key, e.g. `Key (name)=(region) already exists.`.
// It returns nil when err is not a PostgreSQL error it knows.
func MapPgError(err error, what string) error {
	var pgErr *pgconn.PgError
	if !errors.As(err, &pgErr) {
		return nil
	}
	switch pgErr.Code {
	case "23505": // unique_violation
		return fmt.Errorf("%s: %s: %w", what, strings.TrimSuffix(pgErr.Detail, "."), domain.ErrConflict)
	case "23503": // foreign_key_violation
		return fmt.Errorf("%s: parent workspace: %w", what, domain.ErrNotFound)
	case "23514", "22P02": // check_violation, invalid_text_representation
		return fmt.Errorf("%s: %s: %w", what, pgErr.Message, domain.ErrInvalid)
	}
	return nil
}
