-- name: CreateBook :one
INSERT INTO books (title, description, year, available)
VALUES (
    sqlc.arg(title),
    sqlc.arg(description),
    sqlc.arg(year),
    sqlc.arg(available)
)
RETURNING id, title, description, year, available, created_at, updated_at;

-- name: GetBook :one
SELECT id, title, description, year, available, created_at, updated_at
FROM books
WHERE id = sqlc.arg(id);

-- name: UpdateBook :one
UPDATE books
SET title = sqlc.arg(title),
    description = sqlc.arg(description),
    year = sqlc.arg(year),
    available = sqlc.arg(available),
    updated_at = NOW()
WHERE id = sqlc.arg(id)
RETURNING id, title, description, year, available, created_at, updated_at;

-- name: DeleteBook :execrows
DELETE FROM books WHERE id = sqlc.arg(id);

-- name: AddBookAudit :exec
INSERT INTO book_audit (book_id, action)
VALUES (sqlc.arg(book_id), sqlc.arg(action));

-- name: CountBooks :one
WITH f AS (
    SELECT sqlc.narg(title)::text AS title,
           sqlc.narg(keyword)::text AS keyword,
           sqlc.narg(year)::int AS year,
           sqlc.narg(available)::boolean AS available
)
SELECT count(*)::bigint
FROM books b CROSS JOIN f
WHERE (f.title IS NULL OR b.title ILIKE '%' || f.title || '%')
  AND (f.keyword IS NULL OR
       b.title ILIKE '%' || f.keyword || '%' OR
       b.description ILIKE '%' || f.keyword || '%')
  AND (f.year IS NULL OR b.year = f.year)
  AND (f.available IS NULL OR b.available = f.available);

-- name: ListBooks :many
WITH f AS (
    SELECT sqlc.narg(title)::text AS title,
           sqlc.narg(keyword)::text AS keyword,
           sqlc.narg(year)::int AS year,
           sqlc.narg(available)::boolean AS available,
           sqlc.arg(sort_by)::text AS sort_by,
           sqlc.arg(sort_dir)::text AS sort_dir
)
SELECT b.id, b.title, b.description, b.year, b.available, b.created_at, b.updated_at
FROM books b CROSS JOIN f
WHERE (f.title IS NULL OR b.title ILIKE '%' || f.title || '%')
  AND (f.keyword IS NULL OR
       b.title ILIKE '%' || f.keyword || '%' OR
       b.description ILIKE '%' || f.keyword || '%')
  AND (f.year IS NULL OR b.year = f.year)
  AND (f.available IS NULL OR b.available = f.available)
ORDER BY
    CASE WHEN f.sort_by = 'title' AND f.sort_dir = 'asc' THEN b.title END ASC,
    CASE WHEN f.sort_by = 'title' AND f.sort_dir = 'desc' THEN b.title END DESC,
    CASE WHEN f.sort_by = 'year' AND f.sort_dir = 'asc' THEN b.year END ASC,
    CASE WHEN f.sort_by = 'year' AND f.sort_dir = 'desc' THEN b.year END DESC,
    CASE WHEN f.sort_by = 'created_at' AND f.sort_dir = 'asc' THEN b.created_at END ASC,
    CASE WHEN f.sort_by = 'created_at' AND f.sort_dir = 'desc' THEN b.created_at END DESC,
    b.id ASC
LIMIT sqlc.arg(page_limit)::int
OFFSET sqlc.arg(page_offset)::int;
