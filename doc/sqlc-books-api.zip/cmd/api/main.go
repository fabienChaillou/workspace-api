package main

import (
	"context"
	"log"
	"os"
	"time"

	"example.com/sqlc-books-api/internal/handler"
	"example.com/sqlc-books-api/internal/repository"
	"example.com/sqlc-books-api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5/pgxpool"
)

func main() {
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" { log.Fatal("DATABASE_URL is required") }
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil { log.Fatal(err) }
	defer pool.Close()
	if err := pool.Ping(ctx); err != nil { log.Fatal(err) }

	repo := repository.NewPostgresBooks(pool)
	svc := service.NewBooks(repo)
	h := handler.NewBooks(svc)
	r := gin.New()
	r.Use(gin.Logger(), gin.Recovery())
	r.GET("/healthz", func(c *gin.Context) { c.JSON(200, gin.H{"status":"ok"}) })
	h.Register(r)
	addr := os.Getenv("HTTP_ADDR")
	if addr == "" { addr = ":8080" }
	log.Printf("listening on %s", addr)
	log.Fatal(r.Run(addr))
}
