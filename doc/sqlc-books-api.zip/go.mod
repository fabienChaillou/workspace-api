module example.com/sqlc-books-api

go 1.24.0

require (
	github.com/gin-gonic/gin v1.10.1
	github.com/jackc/pgx/v5 v5.7.2
	github.com/testcontainers/testcontainers-go/modules/postgres v0.37.0
)
