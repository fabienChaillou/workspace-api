package domain

import "time"

type Book struct {
	ID          int64     `json:"id"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	Year        int32     `json:"year"`
	Available   bool      `json:"available"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type CreateBookInput struct {
	Title       string `json:"title" binding:"required"`
	Description string `json:"description"`
	Year        int32  `json:"year" binding:"required"`
	Available   *bool  `json:"available"`
}

type UpdateBookInput struct {
	Title       string `json:"title" binding:"required"`
	Description string `json:"description"`
	Year        int32  `json:"year" binding:"required"`
	Available   bool   `json:"available"`
}

type BookFilter struct {
	Title     string
	Keyword   string
	Year      *int32
	Available *bool
	Limit     int32
	Offset    int32
	SortBy    string
	SortDir   string
}

type BookPage struct {
	Items  []Book `json:"items"`
	Total  int64  `json:"total"`
	Limit  int32  `json:"limit"`
	Offset int32  `json:"offset"`
}
