package service

import (
	"context"
	"errors"
	"strings"

	"example.com/sqlc-books-api/internal/domain"
	"example.com/sqlc-books-api/internal/repository"
)

type Books struct { repo repository.Books }

func NewBooks(repo repository.Books) *Books { return &Books{repo: repo} }

func (s *Books) Create(ctx context.Context, in domain.CreateBookInput) (domain.Book, error) {
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" { return domain.Book{}, errors.New("title is required") }
	if in.Year < 0 || in.Year > 3000 { return domain.Book{}, errors.New("year must be between 0 and 3000") }
	return s.repo.Create(ctx, in)
}
func (s *Books) Get(ctx context.Context, id int64) (domain.Book, error) {
	if id <= 0 { return domain.Book{}, errors.New("id must be positive") }
	return s.repo.Get(ctx, id)
}
func (s *Books) Update(ctx context.Context, id int64, in domain.UpdateBookInput) (domain.Book, error) {
	in.Title = strings.TrimSpace(in.Title)
	if id <= 0 { return domain.Book{}, errors.New("id must be positive") }
	if in.Title == "" { return domain.Book{}, errors.New("title is required") }
	if in.Year < 0 || in.Year > 3000 { return domain.Book{}, errors.New("year must be between 0 and 3000") }
	return s.repo.Update(ctx, id, in)
}
func (s *Books) Delete(ctx context.Context, id int64) error {
	if id <= 0 { return errors.New("id must be positive") }
	return s.repo.Delete(ctx, id)
}
func (s *Books) List(ctx context.Context, f domain.BookFilter) (domain.BookPage, error) {
	if f.Limit < 1 || f.Limit > 100 { return domain.BookPage{}, errors.New("limit must be between 1 and 100") }
	if f.Offset < 0 { return domain.BookPage{}, errors.New("offset must be non-negative") }
	switch f.SortBy {
	case "", "created_at", "title", "year":
	default: return domain.BookPage{}, errors.New("sort_by must be title, year or created_at")
	}
	if f.SortBy == "" { f.SortBy = "created_at" }
	switch strings.ToLower(f.SortDir) {
	case "", "asc": f.SortDir = "asc"
	case "desc": f.SortDir = "desc"
	default: return domain.BookPage{}, errors.New("sort_dir must be asc or desc")
	}
	f.Title = strings.TrimSpace(f.Title)
	f.Keyword = strings.TrimSpace(f.Keyword)
	return s.repo.List(ctx, f)
}
