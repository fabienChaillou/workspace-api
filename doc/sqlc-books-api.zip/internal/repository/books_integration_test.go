package repository_test

import (
	"context"
	"path/filepath"
	"os"
	"testing"

	"example.com/sqlc-books-api/internal/domain"
	"example.com/sqlc-books-api/internal/repository"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/testcontainers/testcontainers-go/modules/postgres"
)

func TestBooksIntegration(t *testing.T) {
	ctx := context.Background()
	ctr, err := postgres.Run(ctx, "postgres:16-alpine",
		postgres.WithDatabase("books_test"),
		postgres.WithUsername("test"),
		postgres.WithPassword("test"),
		postgres.BasicWaitStrategies(),
	)
	if err != nil { t.Fatalf("start postgres: %v", err) }
	t.Cleanup(func() {
		if err := ctr.Terminate(ctx); err != nil { t.Logf("terminate postgres: %v", err) }
	})
	dsn, err := ctr.ConnectionString(ctx, "sslmode=disable")
	if err != nil { t.Fatal(err) }
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil { t.Fatal(err) }
	t.Cleanup(pool.Close)

	schema, err := osReadFile(filepath.Join("..", "..", "sql", "schema.sql"))
	if err != nil { t.Fatal(err) }
	if _, err := pool.Exec(ctx, string(schema)); err != nil { t.Fatalf("apply schema: %v", err) }

	repo := repository.NewPostgresBooks(pool)
	available := true
	book, err := repo.Create(ctx, domain.CreateBookInput{
		Title:"Go in Action", Description:"Go programming book", Year:2015, Available:&available,
	})
	if err != nil { t.Fatalf("create: %v", err) }
	if book.ID == 0 { t.Fatal("expected generated ID") }

	got, err := repo.Get(ctx, book.ID)
	if err != nil { t.Fatalf("get: %v", err) }
	if got.Title != "Go in Action" { t.Fatalf("title = %q", got.Title) }

	year := int32(2015)
	page, err := repo.List(ctx, domain.BookFilter{
		Keyword:"programming", Year:&year, Limit:10, Offset:0, SortBy:"title", SortDir:"asc",
	})
	if err != nil { t.Fatalf("list: %v", err) }
	if page.Total != 1 || len(page.Items) != 1 { t.Fatalf("unexpected page: %+v", page) }

	updated, err := repo.Update(ctx, book.ID, domain.UpdateBookInput{
		Title:"Go in Action 2nd Edition", Description:"updated", Year:2016, Available:false,
	})
	if err != nil { t.Fatalf("update: %v", err) }
	if updated.Year != 2016 || updated.Available { t.Fatalf("unexpected update: %+v", updated) }

	if err := repo.Delete(ctx, book.ID); err != nil { t.Fatalf("delete: %v", err) }
	if _, err := repo.Get(ctx, book.ID); err != repository.ErrNotFound { t.Fatalf("expected ErrNotFound, got %v", err) }

	// Ensure the create and audit insert were committed in the same transaction.
	var auditCount int
	if err := pool.QueryRow(ctx, "SELECT count(*) FROM book_audit WHERE book_id=$1", book.ID).Scan(&auditCount); err != nil { t.Fatal(err) }
	if auditCount != 1 { t.Fatalf("audit count = %d, want 1", auditCount) }
}

func osReadFile(path string) ([]byte, error) {
	return os.ReadFile(path)
}
