package repository

import (
	"context"
	"errors"
	"time"

	"example.com/sqlc-books-api/internal/db/sqlc"
	"example.com/sqlc-books-api/internal/domain"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgx/v5/pgtype"
)

var ErrNotFound = errors.New("book not found")

type Books interface {
	Create(context.Context, domain.CreateBookInput) (domain.Book, error)
	Get(context.Context, int64) (domain.Book, error)
	Update(context.Context, int64, domain.UpdateBookInput) (domain.Book, error)
	Delete(context.Context, int64) error
	List(context.Context, domain.BookFilter) (domain.BookPage, error)
}

type PostgresBooks struct {
	pool *pgxpool.Pool
	q    *db.Queries
}

func NewPostgresBooks(pool *pgxpool.Pool) *PostgresBooks {
	return &PostgresBooks{pool: pool, q: db.New(pool)}
}

func (r *PostgresBooks) Create(ctx context.Context, in domain.CreateBookInput) (domain.Book, error) {
	available := true
	if in.Available != nil {
		available = *in.Available
	}
	tx, err := r.pool.Begin(ctx)
	if err != nil {
		return domain.Book{}, err
	}
	defer tx.Rollback(ctx)

	qtx := r.q.WithTx(tx)
	row, err := qtx.CreateBook(ctx, db.CreateBookParams{
		Title: in.Title, Description: in.Description, Year: in.Year, Available: available,
	})
	if err != nil {
		return domain.Book{}, err
	}
	if err := qtx.AddBookAudit(ctx, db.AddBookAuditParams{BookID: row.ID, Action: "created"}); err != nil {
		return domain.Book{}, err
	}
	if err := tx.Commit(ctx); err != nil {
		return domain.Book{}, err
	}
	return fromRow(row.ID, row.Title, row.Description, row.Year, row.Available, row.CreatedAt, row.UpdatedAt), nil
}

func (r *PostgresBooks) Get(ctx context.Context, id int64) (domain.Book, error) {
	row, err := r.q.GetBook(ctx, id)
	if errors.Is(err, pgx.ErrNoRows) {
		return domain.Book{}, ErrNotFound
	}
	if err != nil {
		return domain.Book{}, err
	}
	return fromRow(row.ID, row.Title, row.Description, row.Year, row.Available, row.CreatedAt, row.UpdatedAt), nil
}

func (r *PostgresBooks) Update(ctx context.Context, id int64, in domain.UpdateBookInput) (domain.Book, error) {
	row, err := r.q.UpdateBook(ctx, db.UpdateBookParams{
		ID: id, Title: in.Title, Description: in.Description, Year: in.Year, Available: in.Available,
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return domain.Book{}, ErrNotFound
	}
	if err != nil {
		return domain.Book{}, err
	}
	return fromRow(row.ID, row.Title, row.Description, row.Year, row.Available, row.CreatedAt, row.UpdatedAt), nil
}

func (r *PostgresBooks) Delete(ctx context.Context, id int64) error {
	n, err := r.q.DeleteBook(ctx, id)
	if err != nil {
		return err
	}
	if n == 0 {
		return ErrNotFound
	}
	return nil
}

func (r *PostgresBooks) List(ctx context.Context, f domain.BookFilter) (domain.BookPage, error) {
	params := db.ListBooksParams{
		Title: nullableText(f.Title), Keyword: nullableText(f.Keyword),
		Year: nullableInt4(f.Year), Available: nullableBool(f.Available),
		SortBy: f.SortBy, SortDir: f.SortDir, PageLimit: f.Limit, PageOffset: f.Offset,
	}
	rows, err := r.q.ListBooks(ctx, params)
	if err != nil {
		return domain.BookPage{}, err
	}
	count, err := r.q.CountBooks(ctx, db.CountBooksParams{
		Title: nullableText(f.Title), Keyword: nullableText(f.Keyword),
		Year: nullableInt4(f.Year), Available: nullableBool(f.Available),
	})
	if err != nil {
		return domain.BookPage{}, err
	}
	items := make([]domain.Book, 0, len(rows))
	for _, row := range rows {
		items = append(items, fromRow(row.ID, row.Title, row.Description, row.Year, row.Available, row.CreatedAt, row.UpdatedAt))
	}
	return domain.BookPage{Items: items, Total: count, Limit: f.Limit, Offset: f.Offset}, nil
}

func nullableText(s string) pgtype.Text {
	return pgtype.Text{String: s, Valid: s != ""}
}
func nullableInt4(v *int32) pgtype.Int4 {
	if v == nil { return pgtype.Int4{} }
	return pgtype.Int4{Int32: *v, Valid: true}
}
func nullableBool(v *bool) pgtype.Bool {
	if v == nil { return pgtype.Bool{} }
	return pgtype.Bool{Bool: *v, Valid: true}
}
func fromRow(id int64, title, description string, year int32, available bool, createdAt, updatedAt time.Time) domain.Book {
	return domain.Book{ID: id, Title: title, Description: description, Year: year, Available: available, CreatedAt: createdAt, UpdatedAt: updatedAt}
}
