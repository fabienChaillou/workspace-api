package handler

import (
	"errors"
	"net/http"
	"strconv"

	"example.com/sqlc-books-api/internal/domain"
	"example.com/sqlc-books-api/internal/repository"
	"example.com/sqlc-books-api/internal/service"
	"github.com/gin-gonic/gin"
)

type Books struct { service *service.Books }
func NewBooks(s *service.Books) *Books { return &Books{service: s} }

func (h *Books) Register(r gin.IRouter) {
	r.POST("/books", h.create)
	r.GET("/books", h.list)
	r.GET("/books/:id", h.get)
	r.PUT("/books/:id", h.update)
	r.DELETE("/books/:id", h.delete)
}
func (h *Books) create(c *gin.Context) {
	var in domain.CreateBookInput
	if err := c.ShouldBindJSON(&in); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
	book, err := h.service.Create(c.Request.Context(), in)
	if err != nil { writeError(c, err); return }
	c.JSON(http.StatusCreated, book)
}
func (h *Books) list(c *gin.Context) {
	limit, err := queryInt32(c, "limit", 20)
	if err != nil { c.JSON(400, gin.H{"error": err.Error()}); return }
	offset, err := queryInt32(c, "offset", 0)
	if err != nil { c.JSON(400, gin.H{"error": err.Error()}); return }
	f := domain.BookFilter{Title:c.Query("title"), Keyword:c.Query("keyword"), Limit:limit, Offset:offset, SortBy:c.DefaultQuery("sort_by","created_at"), SortDir:c.DefaultQuery("sort_dir","desc")}
	if raw := c.Query("year"); raw != "" { v, e := strconv.ParseInt(raw,10,32); if e != nil { c.JSON(400,gin.H{"error":"year must be an integer"}); return }; y:=int32(v); f.Year=&y }
	if raw := c.Query("available"); raw != "" { v,e:=strconv.ParseBool(raw); if e != nil { c.JSON(400,gin.H{"error":"available must be true or false"}); return }; f.Available=&v }
	page, err := h.service.List(c.Request.Context(), f)
	if err != nil { writeError(c,err); return }
	c.JSON(http.StatusOK,page)
}
func (h *Books) get(c *gin.Context) {
	id, err := pathID(c); if err != nil { c.JSON(400,gin.H{"error":err.Error()}); return }
	book, err := h.service.Get(c.Request.Context(),id); if err != nil { writeError(c,err); return }
	c.JSON(200,book)
}
func (h *Books) update(c *gin.Context) {
	id, err := pathID(c); if err != nil { c.JSON(400,gin.H{"error":err.Error()}); return }
	var in domain.UpdateBookInput
	if err := c.ShouldBindJSON(&in); err != nil { c.JSON(400,gin.H{"error":err.Error()}); return }
	book, err := h.service.Update(c.Request.Context(),id,in); if err != nil { writeError(c,err); return }
	c.JSON(200,book)
}
func (h *Books) delete(c *gin.Context) {
	id, err := pathID(c); if err != nil { c.JSON(400,gin.H{"error":err.Error()}); return }
	if err := h.service.Delete(c.Request.Context(),id); err != nil { writeError(c,err); return }
	c.Status(http.StatusNoContent)
}
func pathID(c *gin.Context) (int64,error) {
	id,err:=strconv.ParseInt(c.Param("id"),10,64); if err!=nil || id<=0 { return 0,errors.New("id must be a positive integer") }; return id,nil
}
func queryInt32(c *gin.Context,key string,def int32)(int32,error) {
	raw:=c.Query(key); if raw=="" { return def,nil }; v,err:=strconv.ParseInt(raw,10,32); if err!=nil { return 0,errors.New(key+" must be an integer") }; return int32(v),nil
}
func writeError(c *gin.Context,err error) {
	if errors.Is(err,repository.ErrNotFound) { c.JSON(404,gin.H{"error":"book not found"}); return }
	c.JSON(400,gin.H{"error":err.Error()})
}
