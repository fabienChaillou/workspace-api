# sqlc-books-api

Exemple Go / PostgreSQL avec sqlc, pgx/v5, Gin et Testcontainers.

## Prérequis
- Go 1.24+
- Docker démarré
- sqlc installé (`brew install sqlc` sur macOS)

## Générer et tester
```bash
go mod tidy
sqlc generate
go test ./...
```

Le test d'intégration démarre un PostgreSQL 16 éphémère via Testcontainers. Il faut donc un runtime Docker actif.

## Démarrer l'API
Appliquer `sql/schema.sql` à votre base, puis :
```bash
export DATABASE_URL='postgres://app:secret@localhost:5432/books?sslmode=disable'
export HTTP_ADDR=':8080'
go run ./cmd/api
```

## Exemples HTTP
```bash
curl -X POST localhost:8080/books -H 'content-type: application/json' \
  -d '{"title":"Go in Action","description":"Go programming","year":2015,"available":true}'

curl 'localhost:8080/books?keyword=programming&year=2015&available=true&limit=10&offset=0&sort_by=title&sort_dir=asc'
curl localhost:8080/books/1
curl -X PUT localhost:8080/books/1 -H 'content-type: application/json' \
  -d '{"title":"Go in Action 2nd Edition","description":"Updated","year":2016,"available":false}'
curl -X DELETE localhost:8080/books/1
```

## Notes d'architecture
- `handler`: HTTP uniquement.
- `service`: règles métier et validation.
- `repository`: adaptation entre domaine et sqlc.
- `internal/db/sqlc`: code généré, ne pas modifier à la main.
- La création du livre et l'insertion dans `book_audit` sont atomiques.
- Le tri est choisi parmi des valeurs autorisées et exprimé en `CASE` SQL : aucune colonne arbitraire n'est interpolée dans la requête.
- `ListBooks` et `CountBooks` partagent les mêmes filtres.

Pour la production, placez les changements de schéma dans un outil de migration (golang-migrate, Goose, Atlas, etc.) plutôt que d'appliquer `schema.sql` directement.
